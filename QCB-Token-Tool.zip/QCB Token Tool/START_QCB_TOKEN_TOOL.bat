@echo off
title QCB Token Tool

rem run as administrator (so the clicks work in the game)
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"
if not exist "setup\python_path.txt" (
    echo Setup has not been run yet - opening it now...
    start "" "%~dp0setup\SETUP.bat"
    exit /b
)

set /p PYEXE=<"setup\python_path.txt"
for %%Z in ("%PYEXE%") do set "PYW=%%~dpZpythonw.exe"
if not exist "%PYW%" set "PYW=%PYEXE%"
start "" "%PYW%" "%~dp0fortnite_loop_bot.py"
exit /b
