QCB TOKEN TOOL  -  made by -gy
==============================

FIRST TIME ONLY
  1. Right-click the downloaded zip -> Extract All (do not run files from inside the zip).
  2. Open the "setup" folder and double-click SETUP.bat.
  3. Click Yes on the administrator prompt. A cmd window opens and installs
     Python and everything the tool needs, then puts a shortcut on your desktop.

EVERY TIME AFTER
  Double-click the "QCB Token Tool" shortcut on your desktop
  (or START_QCB_TOKEN_TOOL.bat in this folder). No VS Code needed.

USING IT
  Queue your first match yourself, then press START in the window and switch
  to Fortnite. When the match ends it clicks CONTINUE, SKIP, PLAY AGAIN.
  Emergency stop: move the mouse into the top-left corner of the screen.

IF THE WINDOW DOES NOT OPEN
  Double-click setup\run_with_console.bat - it shows the error message.
