@echo off
setlocal EnableExtensions
title QCB Token Tool - Setup  (made by -gy)
color 0B

rem ---------- 1. make sure we run as administrator ----------
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Asking for administrator rights...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"
set "SETUPDIR=%~dp0"
for %%Z in ("%~dp0..") do set "APPDIR=%%~fZ"

echo ==============================================
echo    QCB TOKEN TOOL  -  SETUP        made by -gy
echo ==============================================
echo.

rem ---------- 2. python ----------
echo [1/4] Looking for Python 3.9 or newer (with tkinter)...
call :findpython
if defined PYEXE goto havepython

echo       Not found. Installing Python 3.12 - this takes a few minutes...
call :installpython
call :findpython
if not defined PYEXE goto nopython

:havepython
echo       Using: %PYEXE%
echo.

rem ---------- 3. libraries ----------
echo [2/4] Updating pip...
"%PYEXE%" -m pip install --upgrade pip --disable-pip-version-check
echo.
echo [3/4] Installing the libraries the tool needs...
"%PYEXE%" -m pip install -r "%SETUPDIR%requirements.txt" --disable-pip-version-check
if errorlevel 1 goto piperror
"%PYEXE%" -c "import cv2, mss, pyautogui, numpy, tkinter"
if errorlevel 1 goto piperror
echo.

rem ---------- 4. shortcut + launcher ----------
echo [4/4] Creating the desktop shortcut...
>"%SETUPDIR%python_path.txt" echo %PYEXE%
powershell -NoProfile -ExecutionPolicy Bypass -File "%SETUPDIR%make_shortcut.ps1" -AppDir "%APPDIR%"
echo.
echo ==============================================
echo    ALL DONE!
echo    Use the "QCB Token Tool" shortcut on your
echo    desktop (or START_QCB_TOKEN_TOOL.bat).
echo ==============================================
echo.
choice /c YN /m "Launch QCB Token Tool now"
if errorlevel 2 goto end
start "" "%APPDIR%\START_QCB_TOKEN_TOOL.bat"
goto end

:nopython
echo.
echo [!] Python could not be installed automatically.
echo     Install it by hand from https://www.python.org/downloads/
echo     (tick "Add python.exe to PATH"), then run this setup again.
goto end

:piperror
echo.
echo [!] Installing or loading the libraries failed. Check your internet
echo     connection, scroll up for the error, then run this setup again.
goto end

:end
echo.
pause
endlocal
exit /b


rem ======================================================
rem  find a usable python -> sets PYEXE (empty if none)
rem ======================================================
:findpython
set "PYEXE="
set "CAND="
for /f "delims=" %%P in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do set "CAND=%%P"
if defined CAND call :checkpython "%CAND%"
if defined PYEXE goto :eof
for %%P in ("%ProgramFiles%\Python312\python.exe" "%LocalAppData%\Programs\Python\Python312\python.exe" "%ProgramFiles%\Python313\python.exe" "%LocalAppData%\Programs\Python\Python313\python.exe" "%ProgramFiles%\Python311\python.exe" "%LocalAppData%\Programs\Python\Python311\python.exe") do (
    if not defined PYEXE if exist %%P call :checkpython %%P
)
goto :eof

:checkpython
"%~1" -c "import sys, tkinter; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>&1
if %errorlevel%==0 set "PYEXE=%~1"
goto :eof


rem ======================================================
rem  download + silently install Python 3.12 (winget fallback)
rem ======================================================
:installpython
set "PYINST=%TEMP%\python-3.12.8-amd64.exe"
if exist "%PYINST%" del /q "%PYINST%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; try { Invoke-WebRequest -UseBasicParsing -Uri 'https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe' -OutFile '%PYINST%' } catch { exit 1 }"
if errorlevel 1 goto :trywinget
if not exist "%PYINST%" goto :trywinget
start "" /wait "%PYINST%" /quiet InstallAllUsers=1 PrependPath=1 Include_launcher=1 Include_pip=1 Include_tcltk=1 Include_test=0
goto :eof

:trywinget
echo       Download failed, trying winget instead...
winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
goto :eof
