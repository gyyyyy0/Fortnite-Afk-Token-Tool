param([string]$AppDir)

$desktop = [Environment]::GetFolderPath('Desktop')
$lnk = Join-Path $desktop 'QCB Token Tool.lnk'

$ws = New-Object -ComObject WScript.Shell
$s = $ws.CreateShortcut($lnk)
$s.TargetPath = Join-Path $AppDir 'START_QCB_TOKEN_TOOL.bat'
$s.WorkingDirectory = $AppDir
$s.WindowStyle = 7
$s.IconLocation = (Join-Path $AppDir 'setup\qcb.ico') + ',0'
$s.Description = 'QCB Token Tool - made by -gy'
$s.Save()

# tick "Run as administrator" on the shortcut
$bytes = [System.IO.File]::ReadAllBytes($lnk)
$bytes[0x15] = $bytes[0x15] -bor 0x20
[System.IO.File]::WriteAllBytes($lnk, $bytes)

Write-Host "      Shortcut created on your desktop: QCB Token Tool"
