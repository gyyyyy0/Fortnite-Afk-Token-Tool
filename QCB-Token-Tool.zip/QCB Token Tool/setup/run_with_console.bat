@echo off
title QCB Token Tool (console)
cd /d "%~dp0.."
if not exist "setup\python_path.txt" (
    echo Run SETUP.bat first.
    pause
    exit /b
)
set /p PYEXE=<"setup\python_path.txt"
"%PYEXE%" fortnite_loop_bot.py
echo.
echo The program closed. Any error message is shown above.
pause
